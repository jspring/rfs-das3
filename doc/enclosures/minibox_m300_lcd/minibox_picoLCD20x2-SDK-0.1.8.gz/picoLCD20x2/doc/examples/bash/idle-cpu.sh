#!/bin/bash
 usblcd clear > /dev/null 2>&1
 usblcd backlight 1 > /dev/null 2>&1
 while [ 1 ]; do 
    e=`vmstat | cut -d ' ' -f 40 `
    e=`echo $e | cut -d ' ' -f 2`
    usblcd text 0 1 " Idle CPU:" text 0 13 $e% > /dev/null 2>&1
    sleep 2
 done