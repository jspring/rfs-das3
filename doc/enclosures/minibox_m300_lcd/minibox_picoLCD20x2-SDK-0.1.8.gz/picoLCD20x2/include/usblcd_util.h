#ifndef __USBLCD_UTIL_H__
#define __USBLCD_UTIL_H__

int is_number (const char const * string);

#endif
