CAN Database Summary

ford_cgea1_2_ptcan_2011.dbc:
	- includes all pretty much all messages available on the on the HS CAN BUS, not all signals have been verified however	