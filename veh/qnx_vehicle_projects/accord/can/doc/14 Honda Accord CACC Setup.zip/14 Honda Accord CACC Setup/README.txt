CAN Database Summary

CAN1
	- diagnostic/scantool data

CAN2
	- Pedal Pos, Veh Speed, Eng Speed, Motor Speed, Batt Current, SOC, Generator Torque, Motor Torque,  

CAN3
	- ACC Settings (distance, buttons pressed)

CAN4
	- ACC Settings
	- Lane Departure Alert (LDW) Settings
	
CAN5
	- Radar objects data (distance, relative velocity, position)